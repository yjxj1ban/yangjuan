package io.appium.android.bootstrap;

/**
 * Enumeration for all the command types.
 * 
 */
public enum AndroidCommandType {
  ACTION, SHUTDOWN
}