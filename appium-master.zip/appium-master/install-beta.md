#appium beta install

## global install

Install with:

```
npm install -g appium@beta
```

Start with:

```
appium
```

## local install

Install with:

```
mkdir beta
cd beta
npm init # press <Enter when asked>
npm install appium@beta
```

Start with
```
"node_modules/.bin/appium"
```

