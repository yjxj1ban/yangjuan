#appium npm install

## global install

Install with:

```
npm install -g appium
```

Start with:

```
appium
```

## local install

Install with:

```
mkdir appium-local
cd appium-local
npm init # press <Enter when asked>
npm install appium
```

Start with
```
"node_modules/.bin/appium"
```

