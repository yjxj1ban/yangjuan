"use strict";

module.exports = {
  app: "sample-code/apps/ApiDemos/bin/ApiDemos-debug.apk"
};
