"use strict";

var selendroidKeyboardTests = require('../common/android-keyboard-base');

describe('selendroid - keyboard', selendroidKeyboardTests);
