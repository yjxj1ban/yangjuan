"use strict";

module.exports = {
  app: "assets/UICatalog6.1.app.zip"
};
