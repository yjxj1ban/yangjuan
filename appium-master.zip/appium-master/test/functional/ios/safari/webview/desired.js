module.exports = {
  nativeWebTap: true,
  browserName: 'safari'
};
