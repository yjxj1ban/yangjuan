"use strict";

var androidWebviewTests = require('../common/android-webview-base');

describe('android - webview @skip-ci', androidWebviewTests);
