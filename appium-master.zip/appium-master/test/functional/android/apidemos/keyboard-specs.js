"use strict";

var androidKeyboardTests = require('../../common/android-keyboard-base');

describe('android - keyboard', androidKeyboardTests);
