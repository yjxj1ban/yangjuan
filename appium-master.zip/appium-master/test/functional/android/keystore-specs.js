"use strict";

var testBase = require('../common/keystore-base');

describe("android - keystore @skip-ci", testBase);
