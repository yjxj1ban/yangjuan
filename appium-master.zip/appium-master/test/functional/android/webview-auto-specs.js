"use strict";

var androidAutoWebviewTests = require('../common/android-auto-webview-base');

describe('android - webview - auto @skip-ci', androidAutoWebviewTests);
