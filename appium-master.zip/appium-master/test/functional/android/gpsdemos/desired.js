"use strict";

module.exports = {
  app: require('gps-demo-app'),
  device: 'Android'
};

