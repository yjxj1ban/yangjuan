package ru.gelin.android.weather.notification;

/**
 *  MainActivity class for backward compatibility.
 */
@Deprecated
public class MainActivity extends ru.gelin.android.weather.notification.app.MainActivity {
}
