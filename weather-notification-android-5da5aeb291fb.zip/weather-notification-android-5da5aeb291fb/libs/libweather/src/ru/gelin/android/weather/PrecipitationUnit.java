package ru.gelin.android.weather;

/**
 *  Supported precipitation units.
 */
public enum PrecipitationUnit {
    MM;
}
